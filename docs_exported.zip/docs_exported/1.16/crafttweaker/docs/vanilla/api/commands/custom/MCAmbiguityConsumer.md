# MCAmbiguityConsumer

## Importing the class

It might be required for you to import the package if you encounter any issues (like casting an Array), so better be safe than sorry and add the import at the very top of the file.
```zenscript
import crafttweaker.api.commands.custom.MCAmbiguityConsumer;
```


## Methods

:::group{name=ambiguous}

Return Type: void

```zenscript
MCAmbiguityConsumer.ambiguous(parent as MCCommandNode, child as MCCommandNode, sibling as MCCommandNode, inputs as Collection<string>) as void
```

| Parameter | Type | Description |
|-----------|------|-------------|
| parent | [MCCommandNode](/vanilla/api/commands/custom/MCCommandNode) | No Description Provided |
| child | [MCCommandNode](/vanilla/api/commands/custom/MCCommandNode) | No Description Provided |
| sibling | [MCCommandNode](/vanilla/api/commands/custom/MCCommandNode) | No Description Provided |
| inputs | Collection&lt;string&gt; | No Description Provided |


:::


