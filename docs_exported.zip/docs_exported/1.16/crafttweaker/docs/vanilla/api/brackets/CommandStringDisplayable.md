# CommandStringDisplayable

This is A helper interface for every item that is returned by a BEP!

## Importing the class

It might be required for you to import the package if you encounter any issues (like casting an Array), so better be safe than sorry and add the import at the very top of the file.
```zenscript
import crafttweaker.api.brackets.CommandStringDisplayable;
```


## Properties

| Name | Type | Has Getter | Has Setter | Description |
|------|------|------------|------------|-------------|
| commandString | string | true | false | Returns the BEP to get this thingy |

