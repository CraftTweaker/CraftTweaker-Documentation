# MCPortalSpawnEvent



The event is cancelable.

If the event is canceled, the portal won't be spawned

The event does not have a result.



## Importing the class

It might be required for you to import the package if you encounter any issues (like casting an Array), so better be safe than sorry and add the import at the very top of the file.
```zenscript
import crafttweaker.api.event.block.MCPortalSpawnEvent;
```


## Extending MCBlockEvent

MCPortalSpawnEvent extends [MCBlockEvent](/vanilla/api/event/block/MCBlockEvent). That means all methods available in [MCBlockEvent](/vanilla/api/event/block/MCBlockEvent) are also available in MCPortalSpawnEvent

